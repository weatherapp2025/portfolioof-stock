# Stock Portfolio Tracker

class Portfolio:
    def __init__(self):
        # Hardcoded stocks with quantities
        self.stocks = {'AAPL': 10, 'GOOGL': 5, 'MSFT': 8, 'TSLA': 3, 'AMZN': 4}
        # Manually defined stock prices
        self.prices = {'AAPL': 185.50, 'GOOGL': 142.30, 'MSFT': 378.90, 'TSLA': 248.50, 'AMZN': 178.25}
    
    def display(self):
        print("\n" + "="*60)
        print("📊 STOCK PORTFOLIO")
        print("="*60)
        print(f"{'Stock':<10} {'Qty':<8} {'Price':<12} {'Value'}")
        print("-"*60)
        total = 0
        for stock, qty in self.stocks.items():
            price = self.prices[stock]
            value = qty * price
            total += value
            print(f"{stock:<10} {qty:<8} ${price:<11.2f} ${value:,.2f}")
        print("-"*60)
        print(f"TOTAL: ${total:,.2f}")
        print("="*60)

portfolio = Portfolio()
portfolio.display()